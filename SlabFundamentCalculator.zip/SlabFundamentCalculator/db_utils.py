import os
import psycopg2
from psycopg2.extras import RealDictCursor

def get_db_connection():
    """Create and return a database connection"""
    if 'DATABASE_URL' not in os.environ:
        raise ValueError("DATABASE_URL environment variable is not set")
    try:
        return psycopg2.connect(os.environ['DATABASE_URL'])
    except Exception as e:
        raise ConnectionError(f"Failed to connect to database: {str(e)}")

def save_design(name, params, results):
    """Save a foundation design to the database"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO foundation_designs (
                name, length_a, width_b, thickness_h, rebar_diameter, 
                grid_x, grid_y, concrete_price, steel_price, formwork_price, 
                waste_factor, volume_bet, area_formwork, length_rebar, 
                mass_rebar, cost_concrete, cost_steel, cost_formwork, cost_total
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (
            name, params['A'], params['B'], params['H'], params['rebar_diameter'],
            params['grid_x'], params['grid_y'], params['concrete_price'], 
            params['steel_price'], params['formwork_price'], params['waste_factor'],
            results['volume_bet'], results['area_formwork'], results['length_rebar'],
            results['mass_rebar'], results['cost_concrete'], results['cost_steel'],
            results['cost_formwork'], results['cost_total']
        ))
        
        design_id = cursor.fetchone()[0]
        conn.commit()
        cursor.close()
        conn.close()
        
        return design_id
    except Exception as e:
        raise Exception(f"Failed to save design: {str(e)}")

def get_all_designs():
    """Get all saved foundation designs"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        
        cursor.execute("""
            SELECT * FROM foundation_designs 
            ORDER BY created_at DESC
        """)
        
        designs = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return designs
    except Exception as e:
        raise Exception(f"Failed to retrieve designs: {str(e)}")

def get_design_by_id(design_id):
    """Get a specific design by ID"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        
        cursor.execute("""
            SELECT * FROM foundation_designs 
            WHERE id = %s
        """, (design_id,))
        
        design = cursor.fetchone()
        cursor.close()
        conn.close()
        
        return design
    except Exception as e:
        raise Exception(f"Failed to retrieve design: {str(e)}")

def delete_design(design_id):
    """Delete a design by ID"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM foundation_designs WHERE id = %s", (design_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        raise Exception(f"Failed to delete design: {str(e)}")

def get_regional_pricing():
    """Get all regional pricing options"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        
        cursor.execute("""
            SELECT * FROM regional_pricing 
            ORDER BY region_name
        """)
        
        pricing = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return pricing
    except Exception as e:
        raise Exception(f"Failed to retrieve regional pricing: {str(e)}")

def get_pricing_by_region(region_name):
    """Get pricing for a specific region"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        
        cursor.execute("""
            SELECT * FROM regional_pricing 
            WHERE region_name = %s
        """, (region_name,))
        
        pricing = cursor.fetchone()
        cursor.close()
        conn.close()
        
        return pricing
    except Exception as e:
        raise Exception(f"Failed to retrieve pricing for region: {str(e)}")
