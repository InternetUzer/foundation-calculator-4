import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch
import math

def create_foundation_diagram(A, B, H, rebar_diameter, grid_x, grid_y, filename="foundation_diagram.png"):
    """Create a visual diagram of the foundation layout"""
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    ax1.set_xlim(-0.5, A + 0.5)
    ax1.set_ylim(-0.5, B + 0.5)
    ax1.set_aspect('equal')
    ax1.set_title('Foundation Top View\n(Rebar Grid)', fontsize=14, fontweight='bold')
    ax1.set_xlabel('Length (m)', fontsize=11)
    ax1.set_ylabel('Width (m)', fontsize=11)
    ax1.grid(True, alpha=0.3, linestyle='--')
    
    foundation = FancyBboxPatch((0, 0), A, B, 
                                boxstyle="round,pad=0.02", 
                                edgecolor='black', 
                                facecolor='lightgray', 
                                linewidth=2)
    ax1.add_patch(foundation)
    
    n_x = math.ceil(A / grid_x) + 1
    n_y = math.ceil(B / grid_y) + 1
    
    for i in range(n_y):
        y_pos = min(i * grid_y, B)
        ax1.plot([0, A], [y_pos, y_pos], 'r-', linewidth=1, alpha=0.7)
    
    for i in range(n_x):
        x_pos = min(i * grid_x, A)
        ax1.plot([x_pos, x_pos], [0, B], 'b-', linewidth=1, alpha=0.7)
    
    ax1.text(A/2, -0.3, f'{A:.2f} m', ha='center', fontsize=10, fontweight='bold')
    ax1.text(-0.3, B/2, f'{B:.2f} m', ha='center', rotation=90, fontsize=10, fontweight='bold')
    
    ax1.text(A + 0.3, 0.2, f'Grid X: {grid_x:.2f} m', fontsize=9, color='blue')
    ax1.text(0.2, B + 0.3, f'Grid Y: {grid_y:.2f} m', fontsize=9, color='red')
    
    ax2.set_xlim(-0.5, A + 0.5)
    ax2.set_ylim(-0.2, H + 0.3)
    ax2.set_aspect('equal')
    ax2.set_title('Foundation Side View', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Length (m)', fontsize=11)
    ax2.set_ylabel('Thickness (m)', fontsize=11)
    ax2.grid(True, alpha=0.3, linestyle='--')
    
    side_view = patches.Rectangle((0, 0), A, H, 
                                   edgecolor='black', 
                                   facecolor='lightgray', 
                                   linewidth=2,
                                   hatch='///')
    ax2.add_patch(side_view)
    
    for i in range(n_y):
        y_pos = min(i * grid_y, A)
        if y_pos <= A:
            ax2.plot(y_pos, H/2, 'ro', markersize=4)
    
    ax2.text(A/2, -0.1, f'{A:.2f} m', ha='center', fontsize=10, fontweight='bold')
    ax2.text(-0.3, H/2, f'{H:.2f} m', ha='center', rotation=90, fontsize=10, fontweight='bold')
    
    ax2.text(A + 0.3, H/2, f'Ø {rebar_diameter:.0f} mm', fontsize=9, color='red')
    
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()
    
    return filename
