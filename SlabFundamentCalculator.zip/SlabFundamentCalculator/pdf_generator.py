from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from datetime import datetime
import os

def generate_pdf_report(params, results, filename="foundation_report.pdf"):
    """Generate a PDF report for foundation calculation"""
    
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4
    
    y = height - 2*cm
    
    c.setFont("Helvetica-Bold", 20)
    c.drawString(2*cm, y, "Foundation Calculation Report")
    y -= 1*cm
    
    c.setFont("Helvetica", 10)
    c.drawString(2*cm, y, f"Generated: {datetime.now().strftime('%d.%m.%Y %H:%M')}")
    y -= 1.5*cm
    
    c.setFont("Helvetica-Bold", 14)
    c.drawString(2*cm, y, "Input Parameters")
    y -= 0.8*cm
    
    c.setFont("Helvetica", 11)
    input_data = [
        ("Length (A)", f"{params['A']:.2f} m"),
        ("Width (B)", f"{params['B']:.2f} m"),
        ("Thickness (H)", f"{params['H']:.2f} m"),
        ("Rebar diameter", f"{params['rebar_diameter']:.1f} mm"),
        ("Grid spacing X", f"{params['grid_x']:.2f} m"),
        ("Grid spacing Y", f"{params['grid_y']:.2f} m"),
        ("Concrete price", f"{params['concrete_price']:.2f} rub/m³"),
        ("Steel price", f"{params['steel_price']:.2f} rub/kg"),
        ("Formwork price", f"{params['formwork_price']:.2f} rub/m²"),
        ("Waste factor", f"{params['waste_factor']*100:.1f}%"),
    ]
    
    for label, value in input_data:
        c.drawString(2.5*cm, y, f"{label}:")
        c.drawString(8*cm, y, value)
        y -= 0.6*cm
    
    y -= 1*cm
    
    c.setFont("Helvetica-Bold", 14)
    c.drawString(2*cm, y, "Calculation Results")
    y -= 0.8*cm
    
    c.setFont("Helvetica-Bold", 12)
    c.drawString(2*cm, y, "Materials:")
    y -= 0.7*cm
    
    c.setFont("Helvetica", 11)
    materials_data = [
        ("Concrete volume", f"{results['volume_bet']:.2f} m³"),
        ("Formwork area", f"{results['area_formwork']:.2f} m²"),
        ("Rebar total length", f"{results['length_rebar']:.2f} m"),
        ("Rebar mass", f"{results['mass_rebar']:.2f} kg"),
    ]
    
    for label, value in materials_data:
        c.drawString(2.5*cm, y, f"{label}:")
        c.drawString(8*cm, y, value)
        y -= 0.6*cm
    
    y -= 1*cm
    
    c.setFont("Helvetica-Bold", 12)
    c.drawString(2*cm, y, "Cost Breakdown:")
    y -= 0.7*cm
    
    c.setFont("Helvetica", 11)
    cost_data = [
        ("Concrete cost", f"{results['cost_concrete']:,.2f} rub"),
        ("Steel cost", f"{results['cost_steel']:,.2f} rub"),
        ("Formwork cost", f"{results['cost_formwork']:,.2f} rub"),
    ]
    
    for label, value in cost_data:
        c.drawString(2.5*cm, y, f"{label}:")
        c.drawString(8*cm, y, value)
        y -= 0.6*cm
    
    y -= 0.5*cm
    c.setStrokeColor(colors.black)
    c.line(2*cm, y, 10*cm, y)
    y -= 0.7*cm
    
    c.setFont("Helvetica-Bold", 12)
    c.drawString(2.5*cm, y, "TOTAL COST:")
    c.drawString(8*cm, y, f"{results['cost_total']:,.2f} rub")
    
    c.save()
    return filename
