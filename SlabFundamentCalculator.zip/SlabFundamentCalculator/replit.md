# Foundation Calculator Application

## Overview

This is a slab foundation calculator application built with Streamlit that helps engineers and construction professionals calculate material quantities and costs for concrete slab foundations. The application performs engineering calculations for concrete volume, rebar requirements, formwork area, and total project costs. It includes features for saving designs, generating PDF reports, and creating visual diagrams of foundation layouts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology**: Streamlit web framework
- **Rationale**: Streamlit provides a rapid development framework for data-driven applications with minimal boilerplate code
- **Structure**: Tab-based interface with three main sections: Calculator, Saved Projects, and Calculation History
- **Pros**: Fast prototyping, built-in UI components, automatic reactivity
- **Cons**: Limited customization compared to traditional web frameworks

### Backend Architecture

**Core Calculation Engine**: Python-based mathematical functions
- **Design**: Pure function approach in `calc_slab_fundament()` that takes input parameters and returns calculated results
- **Calculations Include**:
  - Concrete volume with waste factor
  - Formwork surface area (bottom and sides)
  - Rebar grid layout and total length
  - Steel mass based on rebar dimensions
  - Cost breakdown by material type
- **Rationale**: Isolated calculation logic enables testing and reuse across different interfaces

**Data Persistence Layer**: PostgreSQL database with direct psycopg2 connections
- **Schema**: Single `foundation_designs` table storing both input parameters and calculated results
- **Connection Management**: Environment-based configuration using `DATABASE_URL`
- **Design Pattern**: Direct SQL queries without ORM
- **Rationale**: Simpler architecture for a focused application; easier to understand and maintain
- **Trade-off**: Less abstraction but more control over queries

### Report Generation

**PDF Reports**: ReportLab library
- **Purpose**: Generate professional calculation reports with input parameters and results
- **Format**: A4 page size with structured sections for parameters and results
- **Features**: Timestamp, formatted tables, measurement units

**Visual Diagrams**: Matplotlib
- **Purpose**: Create technical drawings showing foundation layout
- **Views**: Top view (rebar grid pattern) and side view (cross-section)
- **Output**: PNG images with dimensional annotations
- **Rationale**: Visual representation aids in understanding and verification of calculations

### Database Schema

**Primary Table**: `foundation_designs`
- Stores complete calculation state including:
  - Project identification (id, name, created_at)
  - Input parameters (dimensions, rebar specs, grid spacing, material prices)
  - Calculated results (volumes, areas, lengths, masses, costs)
- **Design Decision**: Denormalized structure storing both inputs and outputs
- **Rationale**: Simplifies retrieval and ensures historical calculations remain accurate even if calculation logic changes
- **Pros**: Fast queries, complete snapshots, no recalculation needed
- **Cons**: Data duplication, larger storage footprint

### Pricing System

**Regional Pricing Support**: Database functions for location-based material costs
- `get_regional_pricing()`: Retrieves all regional price data
- `get_pricing_by_region()`: Fetches prices for specific region
- **Purpose**: Allows accurate cost estimation based on geographic location
- **Rationale**: Construction material prices vary significantly by region

## External Dependencies

### Database
- **PostgreSQL**: Primary data store
- **psycopg2**: Python PostgreSQL adapter
- **Connection**: Via `DATABASE_URL` environment variable
- **Tables**: `foundation_designs`, regional pricing tables

### Python Libraries
- **streamlit**: Web application framework and UI
- **pandas**: Data manipulation and display in tabular format
- **matplotlib**: Technical diagram generation
- **reportlab**: PDF report generation
- **psycopg2**: PostgreSQL database connectivity

### System Requirements
- Python runtime environment
- PostgreSQL database instance
- File system access for PDF and diagram generation

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string (required)